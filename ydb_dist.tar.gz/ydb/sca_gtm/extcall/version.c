#include <stdio.h>
extern char * version();
main () {

     printf ("\nEXTCALL version info: %s\n", version());
}

