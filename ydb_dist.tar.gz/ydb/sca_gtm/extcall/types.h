#include <sys/types.h>
/*
typedef   unsigned long   size_t;
typedef   signed int      ssize_t;
*/
#define SUCCESS  0
#define FAILURE -1
