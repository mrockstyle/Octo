%ZCHKPTR	;Private;GT.M sparse database checker
	;;Copyright(c)1994 Sanchez Computer Associates, Inc.  All Rights Reserved - 05/04/94 20:39:33 - SYSRUSSELL
	; ORIG:  Dan S. Russell (2417) - 09 Nov 88
	;
	; GT.M sparse database checker - NOT YET IMPLEMENTED
	; M/VX version exists
	;
	Q
